import json
import base64
from io import BytesIO
import base64, os, io
from datetime import datetime
from odoo import http, modules
from odoo.http import request, Response
import xml.etree.ElementTree as ET
import xml.dom.minidom
import zipfile
from pprint import pformat
import logging
from ..models.document_issued import DocumentIssued

_logger = logging.getLogger(__name__)

class PosSessionDownload(http.Controller):
    @http.route('/pos_session/download_json/<int:session_id>', type='http', auth='user', methods=['GET'])
    def download_json(self, session_id, **kwargs):
        # Identificador de la sesion
        session = request.env['pos.session'].sudo().browse(session_id)
        if not session.exists():
            return request.not_found()

        session_data = [{
            'id': session.id,
            'name': session.name,
            'start_at': session.start_at,
            'stop_at': session.stop_at,
            'user_id': session.user_id.name,
            'config_id': session.config_id.name,
            'state': session.state,
        }]

        # Conversion a json
        json_data = json.dumps(session_data, default=str, indent=4)

        # Nombre del archivo
        file_name = f"ventas_session_{session.name}.json"

        # Encabezado del response
        headers = [
            ('Content-Type', 'application/json'),
            ('Content-Disposition', f'attachment; filename="{file_name}"')
        ]
        return request.make_response(json_data, headers=headers)

    @http.route('/pos_session/download_zip/<int:session_id>', type='http', auth='user', methods=['GET'])
    def generate_zip(self, session_id, **kwargs):
        # Identificador de la sesion
        session = request.env['pos.session'].sudo().browse(session_id)
        if not session.exists():
            return request.not_found()

        # Obtener y decodificar los parámetros JSON
        params_json = kwargs.get('params', '{}')
        try:
            params = json.loads(params_json)
            _logger.info('\n\n=== PARÁMETROS RECIBIDOS ===\n%s\n========================\n', 
                        pformat(params))
        except json.JSONDecodeError as e:
            _logger.error('Error al decodificar JSON: %s', str(e))
            params = {}

        # Extraer datos de los parámetros
        date_start = params.get('date_start')
        date_end = params.get('date_end')
        all_dates = params.get('all_dates', False)
        documentos_config = params.get('documentos', {})
        formato = params.get('formato', 'xml')
        envio_correo = params.get('envio_correo', {})


        # cabecera_documentos_emitidos = self.get_doc_issued_data(session_id, date_start, date_end)


        session_data = [{"FProceso": "2024-02-26"}]  # Datos por defecto en caso de error

        # Preparar e inicializa los documentos documentos para el ZIP
        documentos = []
        for nombre, incluir in documentos_config.items():
            if incluir:
                session_data = self.get_document_data(nombre, session_id, date_start, date_end)
                documentos.append({
                    'nombreArchivo': nombre,
                    'datos': session_data,
                })
        
        # Buffer para el zip
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for doc in documentos:
                xml_name, xml_content = self.generate_xml(doc['nombreArchivo'], doc['datos'])
                zip_file.writestr(xml_name, xml_content)

        # Traer contenido del ZIP
        zip_buffer.seek(0)
        zip_content = zip_buffer.read()

        # Obtener la fecha actual en formato YYYYMMDD
        fecha_actual = datetime.now().strftime('%Y%m%d')
        # Constante para el nombre del archivo
        codigo_constante = 'MUVESM200000234'
        # Nombre del archivo
        zip_name = f"{fecha_actual}-{codigo_constante}.zip"

        headers = [
            ('Content-Type', 'application/zip'),
            ('Content-Disposition', f'attachment; filename="{zip_name}"')
        ]
        return request.make_response(zip_content, headers=headers)

    # Metodo para generar un archivo XML
    def generate_xml(self, file_name, data_array):
        # Ruta absoluta de la plantilla
        template_path = os.path.join(modules.get_module_path('o16_pos_sales_export'), 'data', 'templates', 'xml', file_name + '.xml')

        etiqueta_padre = file_name;

        # Verificación de archivo
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"La plantilla XML '{file_name}' no existe en la ruta especificada.")

        # Cargar la plantilla
        tree = ET.parse(template_path)
        root = tree.getroot()

        # Eliminar contenido
        for elem in root.findall(etiqueta_padre):
            root.remove(elem)

        # Agregar datos a la plantilla dinamicamente
        for data in data_array:
            cabecera_element = ET.Element(etiqueta_padre)
            # Cada clave corresponde a una etiqueta
            for key, value in data.items():
                sub_element = ET.Element(key)
                sub_element.text = str(value)
                cabecera_element.append(sub_element)
            # Agregar al XML
            root.append(cabecera_element)  

        # Codificacion de XML
        rough_string = ET.tostring(root, encoding='utf-8')
        reparsed = xml.dom.minidom.parseString(rough_string)
        xml_string = "\n".join([line for line in reparsed.toprettyxml(indent="  ", encoding="utf-8").decode("utf-8").split("\n") if line.strip()])


        # print(xml_string)
        # Nombre del archivo
        # file_name = f"test_{file_name}.xml"

        # Obtener la fecha actual en formato YYYYMMDD
        fecha_actual = datetime.now().strftime('%Y%m%d')
        # Constante para el nombre del archivo
        codigo_constante = 'MUVESM200000234'
        # Generar el nombre del archivo con el nuevo patrón
        file_name = f"{fecha_actual}-{codigo_constante}-{file_name}.xml"

        return file_name, xml_string


    def get_doc_issued_data(self, session_id, start_date, end_date):
        # Consulta SQL con parámetros
        query = """
            SELECT 
                -- po.session_id, po.id AS "order_id", 
                TO_CHAR(
                    (ps.start_at AT TIME ZONE 'UTC') AT TIME ZONE 'America/Lima', 
                    'YYYY-MM-DD"T"HH24:MI:SS-05:00'
                ) AS "FProceso",
                rc.name AS "CiaSocio", sw.code AS "CodAlm",
                CONCAT(sw.code, '#', po.id) AS "IdBach", 
                NULL AS "TDocto", NULL AS "NroDocto", 
                TO_CHAR(am.invoice_date_due AT TIME ZONE 'America/Bogota', 'YYYY-MM-DD"T"00:00:00-05:00') AS "FDocumento",
                rp.vat AS "ClienteRUC", rp.name AS "ClienteNombre", 
                CONCAT(rp.street) AS "ClienteDireccion", 
                NULL AS "CC", NULL AS "Suc", NULL AS "UN", 
                rcy.name AS "MonDocto", am.amount_total AS "MontoAfecto", 
                am.amount_untaxed AS "MontoNoAfecto", am.amount_tax AS "MontoIGV", 
                'E' AS "MontoImp", am.amount_total AS "MontoTotal", 
                'E' AS "PorcRecargo", am.payment_state AS "Estado", 
                NULL AS "DetalleCobranzaFlag", NULL AS "TipoPago", 
                NULL AS "MonedaPago", NULL AS "TipoCambioPago", 
                NULL AS "MontoPago", NULL AS "TarjetaCreditoCodigo", 
                NULL AS "DocumentoReferencia", NULL AS "NumeroAutorizacion", 
                NULL AS "MontoPropina", NULL AS "ProcesadoFlag", 
                NULL AS "FechaProcesado", NULL AS "EstadoProceso", 
                ps.name AS "NumeroLiquidacion", NULL AS "NumeroPersonas", 
                NULL AS "Mozo", ps.user_id AS "Cajero", 
                NULL AS "VentaTiendaFlag", NULL AS "OtrosIngresosFlag", 
                NULL AS "ReservacionFlag", NULL AS "NumeroAdelanto"
            FROM public.pos_order po
            INNER JOIN public.pos_session ps ON ps.id = po.session_id
            INNER JOIN public.res_company rc ON rc.id = po.company_id
            INNER JOIN public.stock_warehouse sw ON rc.id = sw.company_id
            INNER JOIN public.pos_payment pp ON po.id = pp.pos_order_id
            INNER JOIN public.account_move am ON am.id = pp.account_move_id
            INNER JOIN public.res_partner rp ON rp.id = po.partner_id
            INNER JOIN public.res_currency rcy ON am.currency_id = rcy.id
            WHERE po.session_id = %s
            AND TO_CHAR((po.date_order AT TIME ZONE 'UTC') AT TIME ZONE 'America/Lima','YYYY-MM-DD"T"HH24:MI:SS-05:00') BETWEEN %s AND %s;
        """
        request.env.cr.execute(query, (session_id, start_date, end_date))
        return request.env.cr.dictfetchall()


    def get_document_data(self, name, session_id, date_start, date_end):
        if name in [
            'CabeceraDocumentosEmitidos',
            'CierreCaja',
            'DetalleDocumentosFacturacion',
            'DetalleDocumentosInventario',
            'DetalleDocumentosCobranza'
        ]:
            return self.get_doc_issued_data(session_id, date_start, date_end)
        return None